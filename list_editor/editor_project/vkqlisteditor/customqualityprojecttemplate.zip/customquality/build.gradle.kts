plugins {
    id("com.android.library")
}

android {
    namespace = "com.google.android.games.customvkquality"
    compileSdk = 33

    defaultConfig {
        minSdk = 22
        targetSdk = 33
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}
